# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'src/frontend/ui/monitor.ui'
#
# Created by: PyQt5 UI code generator 5.5.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MonitorWindow(object):
    def setupUi(self, MonitorWindow):
        MonitorWindow.setObjectName("MonitorWindow")
        MonitorWindow.resize(50, 50)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Fixed, QtWidgets.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(MonitorWindow.sizePolicy().hasHeightForWidth())
        MonitorWindow.setSizePolicy(sizePolicy)
        MonitorWindow.setMinimumSize(QtCore.QSize(50, 50))
        MonitorWindow.setMaximumSize(QtCore.QSize(50, 50))
        icon = QtGui.QIcon.fromTheme("xware-desktop")
        MonitorWindow.setWindowIcon(icon)
        MonitorWindow.setLocale(QtCore.QLocale(QtCore.QLocale.Chinese, QtCore.QLocale.China))
        self.graphicsView = MonitorGraphicsView(MonitorWindow)
        self.graphicsView.setGeometry(QtCore.QRect(0, 0, 50, 50))
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.graphicsView.sizePolicy().hasHeightForWidth())
        self.graphicsView.setSizePolicy(sizePolicy)
        self.graphicsView.setMaximumSize(QtCore.QSize(50, 50))
        self.graphicsView.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.graphicsView.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarAlwaysOff)
        self.graphicsView.setObjectName("graphicsView")

        self.retranslateUi(MonitorWindow)
        QtCore.QMetaObject.connectSlotsByName(MonitorWindow)

    def retranslateUi(self, MonitorWindow):
        _translate = QtCore.QCoreApplication.translate
        MonitorWindow.setWindowTitle(_translate("MonitorWindow", "Xware Desktop悬浮窗"))

from Widgets.MonitorWidget.MonitorGraphicsView import MonitorGraphicsView
from Widgets.MonitorWidget.MonitorWidget import MonitorWidget
import resource_rc
