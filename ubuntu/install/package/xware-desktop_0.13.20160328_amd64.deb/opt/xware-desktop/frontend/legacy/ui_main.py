# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'src/frontend/ui/main.ui'
#
# Created by: PyQt5 UI code generator 5.5.1
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1008, 759)
        icon = QtGui.QIcon.fromTheme("xware-desktop")
        MainWindow.setWindowIcon(icon)
        MainWindow.setLocale(QtCore.QLocale(QtCore.QLocale.Chinese, QtCore.QLocale.China))
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.centralwidget.sizePolicy().hasHeightForWidth())
        self.centralwidget.setSizePolicy(sizePolicy)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.webView = CustomWebView(self.centralwidget)
        self.webView.setStyleSheet("background-color: white;")
        self.webView.setObjectName("webView")
        self.horizontalLayout.addWidget(self.webView)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1008, 22))
        self.menubar.setObjectName("menubar")
        self.menu_file = QtWidgets.QMenu(self.menubar)
        self.menu_file.setObjectName("menu_file")
        self.menu_help = QtWidgets.QMenu(self.menubar)
        self.menu_help.setObjectName("menu_help")
        self.menu_backend = QtWidgets.QMenu(self.menubar)
        self.menu_backend.setEnabled(False)
        self.menu_backend.setObjectName("menu_backend")
        MainWindow.setMenuBar(self.menubar)
        self.statusBar_main = CustomStatusBar(MainWindow)
        self.statusBar_main.setAutoFillBackground(False)
        self.statusBar_main.setStyleSheet("QStatusBar {\n"
"    background-color: skyblue;\n"
"}\n"
"::item {\n"
"    border: none !important;\n"
"}")
        self.statusBar_main.setObjectName("statusBar_main")
        MainWindow.setStatusBar(self.statusBar_main)
        self.action_showAbout = QtWidgets.QAction(MainWindow)
        icon = QtGui.QIcon.fromTheme("help-about")
        self.action_showAbout.setIcon(icon)
        self.action_showAbout.setObjectName("action_showAbout")
        self.action_exit = QtWidgets.QAction(MainWindow)
        icon = QtGui.QIcon.fromTheme("application-exit")
        self.action_exit.setIcon(icon)
        self.action_exit.setObjectName("action_exit")
        self.action_createTask = QtWidgets.QAction(MainWindow)
        icon = QtGui.QIcon.fromTheme("document-new")
        self.action_createTask.setIcon(icon)
        self.action_createTask.setObjectName("action_createTask")
        self.action_setting = QtWidgets.QAction(MainWindow)
        icon = QtGui.QIcon.fromTheme("document-properties")
        self.action_setting.setIcon(icon)
        self.action_setting.setObjectName("action_setting")
        self.action_refreshPage = QtWidgets.QAction(MainWindow)
        icon = QtGui.QIcon.fromTheme("view-refresh")
        self.action_refreshPage.setIcon(icon)
        self.action_refreshPage.setShortcuts(['Ctrl+R', 'F5'])
        self.action_refreshPage.setObjectName("action_refreshPage")
        self.action_ETMstop = QtWidgets.QAction(MainWindow)
        self.action_ETMstop.setObjectName("action_ETMstop")
        self.action_ETMstart = QtWidgets.QAction(MainWindow)
        self.action_ETMstart.setObjectName("action_ETMstart")
        self.action_ETMrestart = QtWidgets.QAction(MainWindow)
        self.action_ETMrestart.setObjectName("action_ETMrestart")
        self.menu_file.addAction(self.action_createTask)
        self.menu_file.addAction(self.action_refreshPage)
        self.menu_file.addSeparator()
        self.menu_file.addAction(self.action_setting)
        self.menu_file.addSeparator()
        self.menu_file.addAction(self.action_exit)
        self.menu_help.addAction(self.action_showAbout)
        self.menu_backend.addAction(self.action_ETMstart)
        self.menu_backend.addAction(self.action_ETMstop)
        self.menu_backend.addAction(self.action_ETMrestart)
        self.menubar.addAction(self.menu_file.menuAction())
        self.menubar.addAction(self.menu_backend.menuAction())
        self.menubar.addAction(self.menu_help.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Xware Desktop"))
        self.menu_file.setTitle(_translate("MainWindow", "文件"))
        self.menu_help.setTitle(_translate("MainWindow", "帮助"))
        self.menu_backend.setTitle(_translate("MainWindow", "后端"))
        self.action_showAbout.setText(_translate("MainWindow", "关于"))
        self.action_exit.setText(_translate("MainWindow", "退出"))
        self.action_createTask.setText(_translate("MainWindow", "新建任务"))
        self.action_createTask.setShortcut(_translate("MainWindow", "Ctrl+N"))
        self.action_setting.setText(_translate("MainWindow", "设置"))
        self.action_setting.setShortcut(_translate("MainWindow", "Ctrl+Alt+S"))
        self.action_refreshPage.setText(_translate("MainWindow", "刷新页面"))
        self.action_ETMstop.setText(_translate("MainWindow", "停止"))
        self.action_ETMstart.setText(_translate("MainWindow", "开启"))
        self.action_ETMrestart.setText(_translate("MainWindow", "重启"))

from legacy.CustomStatusBar.CStatusBar import CustomStatusBar
from legacy.CustomWebView.CWebView import CustomWebView
import resource_rc
